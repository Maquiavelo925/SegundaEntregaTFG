# ================================================================
#  MakiBosque — Generador de props sobre vértices seleccionados
#  Autor   : Makiavelo925, Álex Cuevas Langa
#  Versión : 1.0.0  |  Blender 4.2+
# ================================================================

bl_info = {
    "name":        "MakiBosque",
    "author":      "Makiavelo925, Álex Cuevas Langa",
    "version":     (1, 0, 0),
    "blender":     (4, 2, 0),
    "location":    "View3D › N-Panel › MakiBosque",
    "description": "Genera props en los vértices seleccionados de un plano",
    "category":    "Add Mesh",
}

import bpy
import bmesh
import random
import math
from mathutils import Matrix, Vector
from bpy.props import IntProperty, PointerProperty, BoolProperty
from bpy.types import PropertyGroup


def rand_obj(col, rng):
    if col is None:
        return None
    objs = [o for o in col.objects if o.type == 'MESH']
    return rng.choice(objs) if objs else None


def place_prop(source, pos_world, normal_world, storage, plane_name, rng,
               random_rot_z, align_to_normal):
    new_obj      = source.copy()
    new_obj.data = source.data.copy()

    tz = normal_world.normalized() if align_to_normal and normal_world.length > 1e-6 else Vector((0, 0, 1))
    angle = rng.uniform(0, math.tau) if random_rot_z else 0.0
    x_ref = Vector((math.cos(angle), math.sin(angle), 0))
    if abs(tz.dot(x_ref)) > 0.99:
        x_ref = Vector((-math.sin(angle), math.cos(angle), 0))
    tx = (x_ref - x_ref.dot(tz) * tz).normalized()
    ty = tz.cross(tx).normalized()

    zs    = [v[2] for v in source.bound_box]
    z_off = -min(zs)
    pos   = pos_world + tz * z_off

    new_obj.matrix_world = Matrix((
        (tx.x, ty.x, tz.x, pos.x),
        (tx.y, ty.y, tz.y, pos.y),
        (tx.z, ty.z, tz.z, pos.z),
        (0,    0,    0,    1     ),
    ))
    new_obj["mbosque_plane"] = plane_name
    new_obj.name = f"MBosque_{new_obj.name}"
    storage.objects.link(new_obj)
    for c in list(new_obj.users_collection):
        if c != storage:
            c.objects.unlink(new_obj)
    return new_obj


class MBosque_Settings(PropertyGroup):
    seed: IntProperty(
        name="Semilla", default=0, min=0, max=999999,
        description="Misma semilla reproduce el mismo resultado",
    )
    collection: PointerProperty(
        name="Colección de assets", type=bpy.types.Collection,
        description="Colección con los objetos a distribuir",
    )
    storage: PointerProperty(
        name="Carpeta de almacenaje", type=bpy.types.Collection,
        description="Colección donde se guardan los props generados",
    )
    random_rot_z: bpy.props.BoolProperty(
        name="Rotación aleatoria en Z", default=True,
        description="Rota cada prop aleatoriamente alrededor de su eje Z",
    )
    align_to_normal: bpy.props.BoolProperty(
        name="Alinear a normal del vértice", default=False,
        description="Orienta el prop según la normal del vértice (útil en terrenos con pendiente)",
    )


class MBosque_OT_generate(bpy.types.Operator):
    """Genera un prop por cada vértice seleccionado."""
    bl_idname  = "makibosque.generate"
    bl_label   = "Generar"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        s   = context.scene.mbosque_settings
        obj = context.active_object
        rng = random.Random(s.seed)

        if s.collection is None:
            self.report({'ERROR'}, "Selecciona una Colección de assets")
            return {'CANCELLED'}
        if s.storage is None:
            self.report({'ERROR'}, "Selecciona una Carpeta de almacenaje")
            return {'CANCELLED'}

        was_edit = (obj.mode == 'EDIT')
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        selected = [v for v in bm.verts if v.select]

        if not selected:
            bm.free()
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
            self.report({'WARNING'}, "No hay vértices seleccionados")
            return {'CANCELLED'}

        mat_obj = obj.matrix_world
        total   = 0

        for v in selected:
            src = rand_obj(s.collection, rng)
            if src is None:
                continue
            pos_w    = mat_obj @ v.co
            normal_w = (mat_obj.to_3x3() @ v.normal).normalized()
            place_prop(src, pos_w, normal_w, s.storage, obj.name, rng,
                       s.random_rot_z, s.align_to_normal)
            total += 1

        bm.free()
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')

        self.report({'INFO'}, f"MakiBosque: {total} prop(s) generado(s)")
        return {'FINISHED'}


class MBosque_OT_clear(bpy.types.Operator):
    """Elimina todos los props generados por MakiBosque del objeto activo."""
    bl_idname  = "makibosque.clear"
    bl_label   = "Limpiar"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        name = context.active_object.name
        old  = [o for o in bpy.data.objects if o.get("mbosque_plane") == name]
        for o in old:
            bpy.data.objects.remove(o, do_unlink=True)
        self.report({'INFO'}, f"MakiBosque: {len(old)} prop(s) eliminado(s)")
        return {'FINISHED'}


class MBosque_PT_main(bpy.types.Panel):
    bl_label       = "MakiBosque"
    bl_idname      = "MBosque_PT_main"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "MakiBosque"

    def draw(self, context):
        layout = self.layout
        s      = context.scene.mbosque_settings
        obj    = context.active_object

        if obj is None or obj.type != 'MESH':
            layout.label(text="Selecciona un objeto Mesh", icon='ERROR')
            return

        box = layout.box()
        box.label(text="Configuración", icon='PREFERENCES')
        box.prop(s, "seed",       text="Semilla")
        box.prop(s, "collection", text="Colección de assets")
        box.prop(s, "storage",    text="Carpeta de almacenaje")

        layout.separator(factor=0.5)

        box2 = layout.box()
        box2.label(text="Opciones de colocación", icon='MODIFIER')
        box2.prop(s, "random_rot_z",    text="Rotación aleatoria en Z")
        box2.prop(s, "align_to_normal", text="Alinear a normal del vértice")

        layout.separator(factor=0.5)

        in_edit = (obj.mode == 'EDIT')
        if in_edit:
            layout.label(text="Selecciona vértices y genera:", icon='VERTEXSEL')
        else:
            layout.label(text="Entra en EditMode para seleccionar", icon='INFO')

        col = layout.column(align=True)
        col.scale_y = 1.5
        col.operator("makibosque.generate", text="Generar", icon='PARTICLE_POINT')
        col.operator("makibosque.clear",    text="Limpiar", icon='TRASH')


classes = [
    MBosque_Settings,
    MBosque_OT_generate,
    MBosque_OT_clear,
    MBosque_PT_main,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mbosque_settings = PointerProperty(type=MBosque_Settings)

def unregister():
    del bpy.types.Scene.mbosque_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
