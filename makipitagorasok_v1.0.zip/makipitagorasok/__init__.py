# ================================================================
#  MakiPitagorasOk — Corrector de ángulos de planos
#  Autor   : Makiavelo925, Álex Cuevas Langa
#  Versión : 1.0.0  |  Blender 4.2+
#
#  Detecta vértices cuyos ángulos internos se salgan del rango
#  [target ± tolerance] y mueve solo ese vértice para corregirlo,
#  dejando el resto de la forma sin tocar.
# ================================================================

bl_info = {
    "name":        "MakiPitagorasOk",
    "author":      "Makiavelo925, Álex Cuevas Langa",
    "version":     (1, 0, 0),
    "blender":     (4, 2, 0),
    "location":    "View3D › N-Panel › MakiPitagorasOk",
    "description": "Corrige ángulos internos de un plano hacia un ángulo objetivo",
    "category":    "Mesh",
}

import bpy
import bmesh
import math
from bpy.props import FloatProperty, IntProperty, PointerProperty
from bpy.types import PropertyGroup


# ================================================================
#  LÓGICA DE CORRECCIÓN (sin dependencias de Blender UI)
# ================================================================

def internal_angle_at_vertex(v, face):
    """
    Ángulo interno (grados) en el vértice v dentro de face.
    Devuelve None si v no pertenece a la cara.
    """
    verts = list(face.verts)
    n     = len(verts)
    for i, vert in enumerate(verts):
        if vert != v:
            continue
        prev_v = verts[(i - 1) % n]
        next_v = verts[(i + 1) % n]
        vec_a  = (prev_v.co - v.co).normalized()
        vec_b  = (next_v.co - v.co).normalized()
        dot    = max(-1.0, min(1.0, vec_a.dot(vec_b)))
        return math.degrees(math.acos(dot))
    return None


def corrected_position(v, face, desired_angle_deg):
    """
    Calcula la nueva posición de v para que su ángulo interno sea
    desired_angle_deg, sin mover los vértices vecinos.

    Busca el punto sobre la bisectriz del ángulo actual a distancia d
    tal que el ángulo resultante sea el deseado. Búsqueda binaria de
    50 pasos → precisión ≈ max_dist / 2^50.
    """
    verts = list(face.verts)
    n     = len(verts)
    for i, vert in enumerate(verts):
        if vert != v:
            continue

        prev_v = verts[(i - 1) % n]
        next_v = verts[(i + 1) % n]
        p = prev_v.co.copy()
        q = next_v.co.copy()
        c = v.co.copy()

        dir_a    = (p - c).normalized()
        dir_b    = (q - c).normalized()
        bisector = (dir_a + dir_b)
        if bisector.length < 1e-6:
            return None           # vértice colineal (180°), sin bisectriz útil
        bisector = bisector.normalized()

        def angle_at(d):
            new_c = c + bisector * d
            da = p - new_c
            db = q - new_c
            if da.length < 1e-8 or db.length < 1e-8:
                return 0.0
            dot = max(-1.0, min(1.0, da.normalized().dot(db.normalized())))
            return math.degrees(math.acos(dot))

        max_dist      = ((p - c).length + (q - c).length) * 0.5
        current_angle = angle_at(0.0)
        desired       = desired_angle_deg

        epsilon       = max_dist * 0.001
        going_up      = angle_at(epsilon) > current_angle

        if desired > current_angle:
            lo, hi = (0.0, max_dist) if going_up else (-max_dist, 0.0)
        else:
            lo, hi = (-max_dist, 0.0) if going_up else (0.0, max_dist)

        # Si el valor deseado no está en el rango elegido, invertir
        a_lo = angle_at(lo)
        a_hi = angle_at(hi)
        if not (min(a_lo, a_hi) <= desired <= max(a_lo, a_hi)):
            lo, hi = -lo, -hi

        # Búsqueda binaria
        for _ in range(50):
            mid = (lo + hi) * 0.5
            a   = angle_at(mid)
            if (a < desired) == (angle_at(lo) < desired):
                lo = mid
            else:
                hi = mid

        return c + bisector * ((lo + hi) * 0.5)

    return None


def run_correction(obj, target_angle, tolerance, max_iters):
    """
    Itera sobre todas las caras y vértices del objeto.
    Mueve solo los vértices cuyo ángulo esté fuera de
    [target_angle - tolerance, target_angle + tolerance].
    Devuelve (total_correcciones, iteraciones_usadas).
    """
    was_edit = (obj.mode == 'EDIT')
    if not was_edit:
        bpy.ops.object.mode_set(mode='EDIT')

    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    low  = target_angle - tolerance
    high = target_angle + tolerance
    corrected_total = 0
    iters_used      = 0

    for iteration in range(max_iters):
        corrected_this = 0
        for face in bm.faces:
            for v in face.verts:
                angle = internal_angle_at_vertex(v, face)
                if angle is None:
                    continue
                if low <= angle <= high:
                    continue

                # Llevar al límite del rango más cercano
                desired = low if angle < low else high
                new_pos = corrected_position(v, face, desired)
                if new_pos is not None:
                    v.co = new_pos
                    corrected_this += 1

        corrected_total += corrected_this
        iters_used       = iteration + 1

        if corrected_this == 0:
            break   # convergencia

    bmesh.update_edit_mesh(obj.data)

    if not was_edit:
        bpy.ops.object.mode_set(mode='OBJECT')

    return corrected_total, iters_used


def collect_angle_report(obj):
    """
    Devuelve una lista de dicts con los ángulos de todos los vértices
    de todas las caras, para mostrar en el panel de diagnóstico.
    """
    was_edit = (obj.mode == 'EDIT')
    if not was_edit:
        bpy.ops.object.mode_set(mode='EDIT')

    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    report = []
    for face in bm.faces:
        for v in face.verts:
            angle = internal_angle_at_vertex(v, face)
            if angle is not None:
                report.append({
                    "face":  face.index,
                    "vert":  v.index,
                    "angle": angle,
                })

    if not was_edit:
        bpy.ops.object.mode_set(mode='OBJECT')

    return report


# ================================================================
#  PROPERTY GROUP
# ================================================================

class MPO_Settings(PropertyGroup):
    target_angle: FloatProperty(
        name        = "Ángulo objetivo",
        description = "Ángulo interno que se intentará alcanzar en cada vértice",
        default     = 90.0,
        min         = 1.0,
        max         = 179.0,
        unit        = 'ROTATION',
        subtype     = 'ANGLE',
    )
    tolerance: FloatProperty(
        name        = "Tolerancia",
        description = "Margen aceptable alrededor del ángulo objetivo (±)",
        default     = 5.0,
        min         = 0.0,
        max         = 45.0,
        unit        = 'ROTATION',
        subtype     = 'ANGLE',
    )
    max_iters: IntProperty(
        name        = "Iteraciones máx.",
        description = "Número máximo de pasadas de corrección",
        default     = 20,
        min         = 1,
        max         = 100,
    )


# ================================================================
#  OPERADOR — Corregir ángulos
# ================================================================

class MPO_OT_correct(bpy.types.Operator):
    """Corrige los vértices con ángulos fuera del rango objetivo."""
    bl_idname  = "makipitagorasok.correct"
    bl_label   = "Corregir ángulos"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        s   = context.scene.mpo_settings
        obj = context.active_object

        # Convertir de radianes (subtype ANGLE) a grados para la lógica
        target_deg = math.degrees(s.target_angle)
        tol_deg    = math.degrees(s.tolerance)

        total, iters = run_correction(obj, target_deg, tol_deg, s.max_iters)

        if total == 0:
            self.report({'INFO'}, "Todos los ángulos ya están dentro del rango. Sin cambios.")
        else:
            self.report(
                {'INFO'},
                f"{total} vértice(s) corregido(s) en {iters} iteración(es). "
                f"Objetivo: {target_deg:.1f}° ± {tol_deg:.1f}°"
            )
        return {'FINISHED'}


# ================================================================
#  OPERADOR — Diagnóstico (imprime en consola)
# ================================================================

class MPO_OT_report(bpy.types.Operator):
    """Imprime en la consola del sistema todos los ángulos internos del objeto."""
    bl_idname = "makipitagorasok.report"
    bl_label  = "Ver ángulos en consola"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        s      = context.scene.mpo_settings
        obj    = context.active_object
        report = collect_angle_report(obj)

        target_deg = math.degrees(s.target_angle)
        tol_deg    = math.degrees(s.tolerance)
        low        = target_deg - tol_deg
        high       = target_deg + tol_deg

        print(f"\n{'═'*48}")
        print(f"  MakiPitagorasOk — {obj.name}")
        print(f"  Objetivo: {target_deg:.1f}° ± {tol_deg:.1f}°  "
              f"[{low:.1f}° — {high:.1f}°]")
        print(f"{'═'*48}")

        out_count = 0
        for r in report:
            status = "OK" if low <= r['angle'] <= high else "⚠ FUERA"
            if status != "OK":
                out_count += 1
            print(f"  Cara {r['face']:>3}  Vért {r['vert']:>4}:  "
                  f"{r['angle']:>7.2f}°  {status}")

        print(f"{'─'*48}")
        print(f"  Total: {len(report)} ángulos  |  "
              f"{out_count} fuera de rango")
        print(f"{'═'*48}\n")

        self.report({'INFO'}, f"{out_count} ángulo(s) fuera de rango. Ver consola del sistema.")
        return {'FINISHED'}


# ================================================================
#  PANEL
# ================================================================

class MPO_PT_main(bpy.types.Panel):
    bl_label       = "MakiPitagorasOk"
    bl_idname      = "MPO_PT_main"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "MakiPitagorasOk"

    def draw(self, context):
        layout = self.layout
        s      = context.scene.mpo_settings
        obj    = context.active_object

        if obj is None or obj.type != 'MESH':
            layout.label(text="Selecciona un objeto Mesh", icon='ERROR')
            return

        # ── Parámetros ──
        box = layout.box()
        box.label(text="Parámetros", icon='DRIVER_ROTATIONAL_DIFFERENCE')

        col = box.column(align=True)
        col.prop(s, "target_angle", text="Ángulo objetivo")
        col.prop(s, "tolerance",    text="Tolerancia  ±")
        col.separator()
        col.prop(s, "max_iters",    text="Iteraciones máx.")

        layout.separator(factor=0.5)

        # ── Información contextual ──
        box_info = layout.box()
        target_deg = math.degrees(s.target_angle)
        tol_deg    = math.degrees(s.tolerance)
        box_info.label(
            text=f"Rango: {target_deg-tol_deg:.1f}° — {target_deg+tol_deg:.1f}°",
            icon='INFO',
        )

        layout.separator(factor=0.5)

        # ── Botones ──
        col = layout.column(align=True)
        col.scale_y = 1.5
        col.operator(
            "makipitagorasok.correct",
            text="Corregir ángulos",
            icon='CON_ROTLIKE',
        )
        col.scale_y = 1.0
        col.separator()
        col.operator(
            "makipitagorasok.report",
            text="Ver ángulos en consola",
            icon='TEXT',
        )


# ================================================================
#  REGISTRO
# ================================================================

classes = [
    MPO_Settings,
    MPO_OT_correct,
    MPO_OT_report,
    MPO_PT_main,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mpo_settings = PointerProperty(type=MPO_Settings)

def unregister():
    del bpy.types.Scene.mpo_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
